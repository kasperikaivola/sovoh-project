//
// Created by Kasperi Kaivola on 19.10.2022.
//

#ifndef _MORSE_H_
#define _MORSE_H_
#include <stdio.h>
#include <unistd.h>
#include <malloc.h>
#include <signal.h>
#include <string.h>

struct Decoder {
  char queue[6]; //stores morse dots and lines, max length of those is 6
  int ind; //index
  int ofd; //output file descriptor
};

char* morseEncode(char x);
void sendAsMorse(char* s, pid_t parentPid);
void readInput(int ifd, pid_t parentPid);
char morseDecode(char* s);
void processMorse(struct Decoder *decoder, char signal);
struct Decoder initDecoder(int ofd);

#endif //_MORSE_H_
