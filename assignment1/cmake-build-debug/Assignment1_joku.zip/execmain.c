#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <assert.h>

#include "morse.h"

static int sigpipe = 0;

static void sigHandler(int signo) {
  /*if(signo==SIGINT) {
      printf("SIGINT received, exiting...\n");
  }*/
  char ret = signo;
  write(sigpipe, &ret, 1);
}

int main(int argc, char **argv) {
  pid_t pid;
  int ifd, ofd, n;
  char buf[129];
  //get file descriptor
  ifd = atoi(argv[1]);
  ofd = atoi(argv[2]);

  pid = fork();
  if (pid == -1) {
    perror("<parent>: Fork failed\n");
    return -1;
  }

  if (pid == 0) {
      readInput(ifd, ppid);
    //kill(ppid, SIGUSR1);
    exit(123);
  } else {
    // We're in parent process
    printf("<parent>: Parent after child created\n");

    pid_t pid = getpid();
    printf("<parent>: Parent PID: %d\n", pid);
    struct sigaction sig;

    int pipefd[2];

    assert(pipe(pipefd) == 0);
    sigpipe = pipefd[1];

    sigemptyset(&sig.sa_mask);
    sig.sa_flags = 0;
    sig.sa_handler = sigHandler;

    assert((sigaction(SIGUSR1, &sig, NULL)) == 0);
    assert((sigaction(SIGUSR2, &sig, NULL)) == 0);

    //int i = 0;
    //int queue[5];

    // init morse decoder
    struct Decoder dec = initDecoder(ofd);

    for (;;) { //morse decoder in parent process
      char mysignal;
      int res = read(pipefd[0], &mysignal, 1);
      // When read is interrupted by a signal, it will return -1 and errno is EINTR.
      if (res == 1) {
        if (mysignal == SIGUSR1) {
          printf("<parent>: received SIGUSR1\n");
          //exit(123);
          //break;
          processMorse(&dec, mysignal);
        } else if (mysignal == SIGUSR2) {
          printf("<parent>: received SIGUSR2\n");
          //break;
          processMorse(&dec, mysignal);
        }
      }
      else if(res==0) break;
    }
    exit(0);
  }


  //int c;
//    while((c=getc(ofd))!=EOF){
//            printf("%c",c);
//    }

//    while ((c = getc(ofd)) != EOF) {
//        printf("%c",c);
//    }
// seems like a stream cannot be passed or read from (fopen ...)
//    while ((n = read(ofd, buf, 128)) > 0) {
//        buf[n] = '\0';  // re-terminate
//        printf("%s",buf);
//        write(ofd, buf, n);
//    }
//    printf("%d",getpid());
//    return 0;
}
